#include "stm32f10x.h"
#include "PWM.h"
#include "SysTick.h"

int main(void)
{
    
	SysTick_Init();//滴答定时器初始化
	TIM3_PWM_Init();//定时器PWM输出初始化(TIM3_CH1)
	
	while(1)
	{
		/* 转动角度0度 */
		TIM_SetCompare1(TIM3, 500);//定时器设置比较值函数和通道有关 时间参数单位是us
		Delay_us(1000000);
		/* 转动角度90度 */
		TIM_SetCompare1(TIM3, 1000);//定时器设置比较值函数和通道有关 时间参数单位是us
		Delay_us(1000000);
		/* 转动角度180度 */
		TIM_SetCompare1(TIM3, 1500);//定时器设置比较值函数和通道有关 时间参数单位是us
		Delay_us(1000000);
		/* 转动角度270度 */
		TIM_SetCompare1(TIM3, 2000);//定时器设置比较值函数和通道有关 时间参数单位是us
		Delay_us(1000000);
		/* 转动角度360度 */
		TIM_SetCompare1(TIM3, 2500);//定时器设置比较值函数和通道有关 时间参数单位是us
		Delay_us(1000000);
	}
}
